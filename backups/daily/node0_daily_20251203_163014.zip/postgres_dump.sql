--
-- PostgreSQL database dump
--

\restrict 0ROVpXlZhwxNk7y28Xy3hQxWHTRfjpH5bn7hyDeTRLXDRecvELbSOnUfBCJda4E

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- PostgreSQL database dump complete
--

\unrestrict 0ROVpXlZhwxNk7y28Xy3hQxWHTRfjpH5bn7hyDeTRLXDRecvELbSOnUfBCJda4E

