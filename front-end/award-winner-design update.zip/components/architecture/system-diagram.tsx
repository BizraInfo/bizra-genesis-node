"use client"

import { useEffect, useRef } from "react"
import mermaid from "mermaid"

export function SystemDiagram() {
  const diagramRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (diagramRef.current) {
      mermaid.initialize({
        startOnLoad: true,
        theme: "dark",
        themeVariables: {
          primaryColor: "#0f172a",
          primaryTextColor: "#fbbf24",
          primaryBorderColor: "#fbbf24",
          lineColor: "#94a3b8",
          secondaryColor: "#2e1065",
          tertiaryColor: "#1e293b",
        },
        fontFamily: "Inter",
      })
      mermaid.run({
        nodes: [diagramRef.current],
      })
    }
  }, [])

  const diagramDefinition = `
graph TD
    %% --- External Actors ---
    User(["User / Operator<br>(The Observer)"])
    
    %% --- Frontend Layer (The Glass Interface) ---
    subgraph Client_Side ["L7: The Public Face (Next.js)"]
        UI_Shell["Glass Interface"]
        Visualizer["3D Citadel Render"]
        Onboarding["Genesis Onboarding"]
        UI_Shell --> Visualizer
        UI_Shell --> Onboarding
    end

    %% --- API Gateway ---
    Gateway["API Gateway"]

    %% --- Core Genesis Node (The Soul) ---
    subgraph Genesis_Node ["BIZRA Genesis Node (Rust)"]
        direction TB
        L0_Engine["L0: Sacred Geometry<br>(Math Kernel)"]
        L1_State["L1: Genesis State<br>(Void/Light)"]
        L2_Ledger["L2: Citadel Ledger<br>(DAG)"]
        L3_Aegis["L3: Aegis Consensus"]
        L4_RSI["L4: RSI Safety"]

        L1_State --> L0_Engine
        L1_State --> L2_Ledger
        L3_Aegis --> L1_State
        L3_Aegis --> L4_RSI
    end

    %% --- AI Layer ---
    subgraph MoE_Cluster ["L5-L6: MoE Swarm"]
        L5_Router["L5: Swarm Router"]
        L6_Inference["L6: Inference"]
        L5_Router --> L6_Inference
    end

    %% --- Relationships ---
    User --> UI_Shell
    UI_Shell --> Gateway
    Gateway --> L1_State
    L4_RSI --> L5_Router
    L6_Inference --> L3_Aegis
`

  return (
    <div className="w-full overflow-hidden rounded-lg border border-[#fbbf24]/20 bg-slate-950/50 p-8 backdrop-blur-sm">
      <h3 className="mb-6 font-serif text-xl text-[#fbbf24]">System Topology v2.0</h3>
      <div ref={diagramRef} className="mermaid flex justify-center">
        {diagramDefinition}
      </div>
    </div>
  )
}
